package com.example.flexifitbackend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.flexifitbackend.entity.Gym;


public interface GymRepository extends JpaRepository<Gym, Long>{

	
//	List<Gym> findBygym_City(String gym_city);
	List<Gym> findBygymcity(String gymcity);

	
// query to find by all the parameters
	
	
	 @Query("SELECT g FROM Gym g WHERE " +
	            "(:gymCity IS NULL OR g.gymcity = :gymCity) AND " +
	            "(:gymRating IS NULL OR g.gym_rating = :gymRating) AND " +
	            "(:gymMembership IS NULL OR " +
	            "(g.gym_platinum = :gymMembership OR g.gym_gold = :gymMembership OR g.gym_silver = :gymMembership))")
	    List<Gym> findByFilters(@Param("gymCity") String gymCity, 
	                            @Param("gymRating") Integer gymRating,
	                            @Param("gymMembership") String gymMembership);
	 
//query to find by city
	 @Query("SELECT g FROM Gym g WHERE (:gymCity IS NULL OR g.gymcity = :gymCity)")
	 List<Gym> findByCity(@Param("gymCity") String gymCity);
	 
//query to find by Rating
	 @Query("SELECT g FROM Gym g WHERE (:gymRating IS NULL OR g.gym_rating = :gymRating)")
	 List<Gym> findByRating(@Param("gymRating")  Integer gymRating);
	 

	 
	 
	 
	

//	List<Gym> findByCityRatingAndMembership(String gym_city, Integer gym_rating, String gym_membership);
//
//	List<Gym> findByCityAndRating(String gym_city, Integer gym_rating);
//
//	List<Gym> findByCityAndMembership(String gym_city, String gym_membership);
//
//	List<Gym> findByRatingAndMembership(Integer gym_rating, String gym_membership);
//
//	List<Gym> findByCity(String gym_city);
//
//	List<Gym> findByRating(Integer gym_rating);
//
//	List<Gym> findByPlatinum(String gym_platinum);
//
//	List<Gym> findByGold(String gym_gold);
//
//	List<Gym> findBySilver(String gym_silver);
	
	
	
	
	
	



	
	
	
	
	
	

}
