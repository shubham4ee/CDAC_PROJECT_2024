package com.example.flexifitbackend.repository;




import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.flexifitbackend.entity.Gym;
import com.example.flexifitbackend.entity.Membership;

@Repository
public interface MembershipRepository extends JpaRepository<Membership, Long> {

	

	List<Membership> findByUserid_Userid(Integer userid);

//	List<Gym> findByUserid(Integer userid);




}
