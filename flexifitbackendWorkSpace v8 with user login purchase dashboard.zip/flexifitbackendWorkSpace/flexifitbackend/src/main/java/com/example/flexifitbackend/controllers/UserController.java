package com.example.flexifitbackend.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.flexifitbackend.entity.Gym;
import com.example.flexifitbackend.entity.User;
import com.example.flexifitbackend.repository.UserRepository;
import com.example.flexifitbackend.services.UserServices;



@RestController
//@RequestMapping("/api/users")
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private UserServices userServices;

    @PostMapping("/register")
    public User registerUser(@RequestBody User user) {
        // You might want to add password encryption here
        return userRepository.save(user);
    }
    
    @RequestMapping("/userreq")
    public void show() {
    	System.out.println(" get method called ");
    }
    
//    @PostMapping
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public void createUser(@RequestBody User user) {
        User savedUser = userRepository.save(user);
        System.out.println("insert success : "+ savedUser);
//        return new UserRepository(savedUser, HttpStatus.CREATED);
    }
    
    
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User loginUser) {
    	
    	User user = userServices.authenticate(loginUser.getUsername(), loginUser.getPassword());
        if (user != null) {
            return ResponseEntity.ok(user);
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid Credentials");
    }
    
    
    
    
    
    
    
    
    
    
    
}
