package com.example.flexifitbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlexifitbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlexifitbackendApplication.class, args);
	}

}
