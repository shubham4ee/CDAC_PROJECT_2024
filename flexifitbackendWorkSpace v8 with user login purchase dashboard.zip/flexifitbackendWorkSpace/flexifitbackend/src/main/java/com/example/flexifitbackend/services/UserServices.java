package com.example.flexifitbackend.services;
import java.util.Collection;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.flexifitbackend.entity.User;
import com.example.flexifitbackend.repository.UserRepository;


@Service//Marks this class as a Service
public class UserServices {


	
	@Autowired //Injecting MovieRepository reference
	private UserRepository userRepositoryRef;


	
	public Collection<User> getAllMovies(){
		//Talks to MovieRepository to get all movies and returns them
		Collection<User> allLoadedUsers=null; 
		return allLoadedUsers;
	}
	
	public User getSingleUser(Integer id) {
		//Talks to MovieRepository to get single movie against its ID and returns it.
		User loadedMovie = null;
		return loadedMovie;
	}
	
	
	public User authenticate(String username, String password) {
        Optional<User> user = userRepositoryRef.findByUsername(username);
        if (user.isPresent() && user.get().getPassword().equals(password)) {
            return user.get();
        }
        return null;
    }
	
	
	
}






