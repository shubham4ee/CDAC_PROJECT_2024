package com.example.flexifitbackend.entity;
import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "membership")
public class Membership {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @Column(name = "membership_id")
    private Long membershipId;

//    @Column(name = "membership_name", nullable = false)
    private String membershipName;

//    @Column(name = "payor_name", nullable = false)
    private String payorName;

//    @Column(name = "payor_phone_no", nullable = false)
    private String payorPhoneNo;

//    @Column(name = "purchase_date")
    private LocalDate purchaseDate;

//    @Column(name = "start_date")
    private LocalDate startDate;

//    @Column(name = "end_date")
    private LocalDate endDate;

    @ManyToOne
    @JoinColumn(name = "userid", referencedColumnName = "userid")
    private User userid;

    // Getters and Setters
    public Long getMembershipId() {
        return membershipId;
    }

    public void setMembershipId(Long membershipId) {
        this.membershipId = membershipId;
    }

    public String getMembershipName() {
        return membershipName;
    }

    public void setMembershipName(String membershipName) {
        this.membershipName = membershipName;
    }

    public String getPayorName() {
        return payorName;
    }

    public void setPayorName(String payorName) {
        this.payorName = payorName;
    }

    public String getPayorPhoneNo() {
        return payorPhoneNo;
    }

    public void setPayorPhoneNo(String payorPhoneNo) {
        this.payorPhoneNo = payorPhoneNo;
    }

    public LocalDate getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(LocalDate purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

	public User getUserid() {
		return userid;
	}

	public void setUserid(User userid) {
		this.userid = userid;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	

   
}

