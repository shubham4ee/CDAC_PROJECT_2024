package com.example.flexifitbackend.services;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.flexifitbackend.entity.Gym;
import com.example.flexifitbackend.entity.Membership;
import com.example.flexifitbackend.repository.MembershipRepository;

import java.util.List;

@Service
public class MembershipService {

    @Autowired
    private MembershipRepository membershipRepository;

    
    public Membership addMembership(Membership membership) {		// working
        return membershipRepository.save(membership);
    }


	public List<Membership> findByUserid(Integer userid) {
		// TODO Auto-generated method stub
		return membershipRepository.findByUserid_Userid(userid);
	}


//	public List<Gym> findByUserid(Integer userid) {
//		// TODO Auto-generated method stub
//		return membershipRepository.findByUserid(userid);
//	}





	
   
    
    
    
}
