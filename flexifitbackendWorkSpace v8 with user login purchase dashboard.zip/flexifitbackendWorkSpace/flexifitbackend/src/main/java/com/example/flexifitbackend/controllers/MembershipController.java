package com.example.flexifitbackend.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.flexifitbackend.entity.Gym;
import com.example.flexifitbackend.entity.Membership;
import com.example.flexifitbackend.services.MembershipService;

import java.util.List;

@RestController
//@RequestMapping("/api/memberships")
@CrossOrigin(origins = "http://localhost:3000")
public class MembershipController {

    @Autowired
    private MembershipService membershipService;

    @RequestMapping(value = "/getMembershipByUserid", method = RequestMethod.POST)		// working
    public List<Membership> getMembershipByUserid(@RequestParam(value = "userid", required = false) Integer userid) {
        System.out.println("Method called with userid: " + userid);
        return membershipService.findByUserid(userid);
    }

    
    
    
    @PostMapping("/addmembership")											//working
    public Membership addEmployee(@RequestBody Membership membership) {
        return membershipService.addMembership(membership);
    }
}
