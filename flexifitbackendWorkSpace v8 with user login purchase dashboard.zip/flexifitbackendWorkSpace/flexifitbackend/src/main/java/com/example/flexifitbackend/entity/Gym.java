package com.example.flexifitbackend.entity;

import org.springframework.stereotype.Component;

import jakarta.persistence.*;
@Component
@Entity

public class Gym {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int  gym_id;
	private String gym_name;
	private String gymcity;
	private int gym_rating;
	private int gym_review;
	private String gym_offer;
	private String gym_platinum;
	private String gym_gold;
	private String gym_silver;
	private byte[] gym_image;
	public int getGym_id() {
		return gym_id;
	}
	public void setGym_id(int gym_id) {
		this.gym_id = gym_id;
	}
	public String getGym_name() {
		return gym_name;
	}
	public void setGym_name(String gym_name) {
		this.gym_name = gym_name;
	}
	public String getGymcity() {
		return gymcity;
	}
	public void setGymcity(String gymcity) {
		this.gymcity = gymcity;
	}
	public int getGym_rating() {
		return gym_rating;
	}
	public void setGym_rating(int gym_rating) {
		this.gym_rating = gym_rating;
	}
	public int getGym_review() {
		return gym_review;
	}
	public void setGym_review(int gym_review) {
		this.gym_review = gym_review;
	}
	public String getGym_offer() {
		return gym_offer;
	}
	public void setGym_offer(String gym_offer) {
		this.gym_offer = gym_offer;
	}
	
	
	
	public String getGym_platinum() {
		return gym_platinum;
	}
	public void setGym_platinum(String gym_platinum) {
		this.gym_platinum = gym_platinum;
	}
	public String getGym_gold() {
		return gym_gold;
	}
	public void setGym_gold(String gym_gold) {
		this.gym_gold = gym_gold;
	}
	public String getGym_silver() {
		return gym_silver;
	}
	public void setGym_silver(String gym_silver) {
		this.gym_silver = gym_silver;
	}
	public byte[] getGym_image() {
		return gym_image;
	}
	public void setGym_image(byte[] gym_image) {
		this.gym_image = gym_image;
	}

	
	
	
	
	

}
