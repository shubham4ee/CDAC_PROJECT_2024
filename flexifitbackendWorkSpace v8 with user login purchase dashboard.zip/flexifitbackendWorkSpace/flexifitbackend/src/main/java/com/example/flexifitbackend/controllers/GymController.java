package com.example.flexifitbackend.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.flexifitbackend.entity.Gym;

import com.example.flexifitbackend.repository.GymRepository;


@RestController
//@RequestMapping("/api/gyms")
@CrossOrigin(origins = "http://localhost:3000")
public class GymController {
	
	@Autowired
    private GymRepository gymRepository;
	
	@RequestMapping(value = "/addGym", method = RequestMethod.POST)
    public void createGym(@RequestBody Gym gym) {
        Gym savedGym = gymRepository.save(gym);
        System.out.println("gym insert success : "+ savedGym);
//        return new UserRepository(savedGym, HttpStatus.CREATED);
    }

	//getting list of gyms with details
//	@GetMapping("/getAllGyms")
//    public List<Gym> getGymList() {
//        return gymRepository.findAll();
//    }
	//getting list of gyms with details
		@GetMapping("/getAllGyms")												// working 
	    public List<Gym> getGymList() {
			System.out.println("Function called");
			System.out.println( gymRepository.findAll());
			return gymRepository.findAll();
	    }
		
//		@RequestMapping(value = "/searchAllGyms", method = RequestMethod.POST)  // working 
//	    public List<Gym> getSearchGymList(@RequestBody Gym gymRef) {
//	        return gymRepository.findAll();
//	    }
		
		
//		@RequestMapping(value = "/searchAllGyms", method = RequestMethod.POST)
//	    public List<Gym> getSearchGymList(@RequestBody Gym gymRef) {
//	        System.out.println("method called");
//	        System.out.println(gymRef.getGymcity());
//	        return gymRepository.findBygymcity(gymRef.getGymcity());
//	    }
		
//		@RequestMapping(value = "/searchAllGyms", method = RequestMethod.POST)		// working with parameters
//	    public void getSearchGymList(@RequestParam(value = "gymcity", required = false) String gymcity,
//	            @RequestParam(value = "rating", required = false) Integer rating
//	           ) {
//	        System.out.println("method called");
//	        System.out.println(gymcity);
////	        return gymRepository.findBygymcity(gymRef.getGymcity());
//	    }
		
		
		

//		@RequestMapping(value = "/searchAllGyms", method = RequestMethod.POST)		// working with parameters
//	    public List<Gym> getSearchGymList(
//	    		@RequestParam(value = "gym_City", required = false) String gym_City,
//	            @RequestParam(value = "gym_Rating", required = false) Integer gym_Rating,
//	            @RequestParam(value = "gym_Membership", required = false) String gym_Membership
//	           ) {
//	        System.out.println("method called");
//	        System.out.println(gym_City);
//	        System.out.println(gym_Rating);
//	        System.out.println(gym_Membership);
//	        return null;
//	        
//	        
//	        
//	        
////	        return gymRepository.findBygymcity(gymRef.getGymcity());
//	    }
		
///// filter gym by all the parameters	
//		@RequestMapping(value = "/searchAllGyms", method = RequestMethod.POST)
//		public List<Gym> getSearchGymList(
//		        @RequestParam(value = "gym_City", required = false) String gym_City,
//		        @RequestParam(value = "gym_Rating", required = false) Integer gym_Rating,
//		        @RequestParam(value = "gym_Membership", required = false) String gym_Membership) {
//
//		    System.out.println("Method called");
//		    System.out.println("Gym City: " + gym_City);
//		    System.out.println("Gym Rating: " + gym_Rating);
//		    System.out.println("Gym Membership: " + gym_Membership);
//
//		    // Retrieve and return the filtered list of gyms using the repository method
//		    return gymRepository.findByFilters(gym_City, gym_Rating, gym_Membership);
//		}
		
/// filter gym by city
		@RequestMapping(value = "/searchGymsbyCity", method = RequestMethod.POST)
		public List<Gym> getSearchGymListbyCity(
		        @RequestParam(value = "gym_City", required = false) String gym_City) {
			gym_City=gym_City.trim();

		    System.out.println("Method called");
		    System.out.println("Gym City: " + gym_City);
		    if (gym_City == "") {
		    	gym_City = null;
		   }

		    // Retrieve and return the filtered list of gyms using the repository method
		    return gymRepository.findByCity(gym_City);
		}

// filter gym by rating 
		@RequestMapping(value = "/searchGymsbyRating", method = RequestMethod.POST)
		public List<Gym> getSearchGymListbyRating(
		        @RequestParam(value = "gym_Rating", required = false) Integer gym_Rating) {

		    System.out.println("Method called");
		    System.out.println("Gym Rating: " + gym_Rating);
		    

		    // Retrieve and return the filtered list of gyms using the repository method
		    return gymRepository.findByRating(gym_Rating);
		}
		
		
		
		
//		
//		@RequestMapping(value = "/searchAllGyms", method = RequestMethod.POST)
//	    public List<Gym> getSearchGymList() {
//	        return gymRepository.findAll();
//	    }
	
//		@RequestMapping(value = "/searchGyms", method = RequestMethod.POST)
//		public void getSearchGymList(@RequestBody Gym gymRef) {
//
//		    System.out.println("Request received successfully");
//		    
//		}
//		    ,
//		    @RequestParam(required = false) Integer gym_rating,
//		    @RequestParam(required = false) String gym_membership
//		    // Handle the search based on the provided parameters
//		    if (gym_city != null && gym_rating != null && gym_membership != null) {
//		        return gymRepository.findByCityRatingAndMembership(gym_city, gym_rating, gym_membership);
//		    } else if (gym_city != null && gym_rating != null) {
//		        return gymRepository.findByCityAndRating(gym_city, gym_rating);
//		    } else if (gym_city != null && gym_membership != null) {
//		        return gymRepository.findByCityAndMembership(gym_city, gym_membership);
//		    } else if (gym_rating != null && gym_membership != null) {
//		        return gymRepository.findByRatingAndMembership(gym_rating, gym_membership);
//		    } else if (gym_city != null) {
//		        return gymRepository.findByCity(gym_city);
//		    } else if (gym_rating != null) {
//		        return gymRepository.findByRating(gym_rating);
//		    } else if (gym_membership != null) {
//		        // Handle specific membership types
//		        switch (gym_membership.toLowerCase()) {
//		            case "platinum":
//		                return gymRepository.findByPlatinum(gym_membership);
//		            case "gold":
//		                return gymRepository.findByGold(gym_membership);
//		            case "silver":
//		                return gymRepository.findBySilver(gym_membership);
//		            default:
//		                // Handle case where membership is not recognized
//		                return gymRepository.findAll(); // or return an empty list if preferred
//		        }
//		    } else {
//		        return gymRepository.findAll();
//		    }
		


		
		
		
}
